//
//  ViewController.swift
//  Find My Age
//
//  Created by mac_rbt on 14/08/19.
//  Copyright © 2019 mac_rbt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var ageLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func calculateMyAge(_ sender: Any) {
       //get selscted date from date picker
        let birthDate = self.datePicker.date
        //yyyy-mm-dd hh:mm:ss +0000
        
        //get today date
        let today = Date()
        
        //cek uur birth date is earlier than today
        if birthDate >= today{
            let alertController = UIAlertController(title: "Error", message: "Please enter a valid date", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "yes", style: .default, handler: nil)
            alertController.addAction(alertAction)
            self.present(alertController,animated: true,completion: nil)
            
        }
        //create an instance of use's current calendar
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year,.month,.day], from: birthDate, to: today)
        guard let ageYears = components.year else {return}
        guard let ageMonth = components.month else {return}
        guard let ageDay = components.day else {return}
        
        self.ageLabel.text = "\(ageYears) years, \(ageMonth) month, \(ageDay) day"
        
    }
    
}

